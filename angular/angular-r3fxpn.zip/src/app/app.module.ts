import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { PortfolioProjectIndividualComponent } from './portfolio-project-individual/portfolio-project-individual.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, HelloComponent, PortfolioProjectIndividualComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
