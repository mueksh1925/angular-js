import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portfolio-project-individual',
  templateUrl: './portfolio-project-individual.component.html',
  styleUrls: ['./portfolio-project-individual.component.css']
})
export class PortfolioProjectIndividualComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}